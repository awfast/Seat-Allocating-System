package Model;

public class Room {

	private int roomNumber;
	
	public Room(int roomNumber) {
		this.roomNumber = roomNumber;
	}
	
	public int getRoomNumber() {
		return this.roomNumber;
	}
}
